function madLib(name, characteristic, verb, adjective) {
  const haiku = `${name} is ${characteristic}
I ${verb} with ${name} often
How ${adjective} I am`;
  console.log(haiku);
}

madLib('Mary', 'merry', 'sing', 'lucky');