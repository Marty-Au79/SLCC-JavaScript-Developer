function greenGlassDoor(word) {
  let letter = '';
  for (let i = 0; i < word.length; i++) {
    const newLetter = word.charAt(i).toLowerCase();
    if (newLetter === letter) {
      return i;
    }
    letter = newLetter;
  }
  return 0;
}

const fruits = ['Banana', 'Apple', 'Pear', 'Grape', 'Cherry'];

for (let frt of fruits) {
  const i = greenGlassDoor(frt);
  if (i) {
    console.log(`${frt} passes: ${frt[i-1]}${frt[i]} at position ${i}.`);
  } else {
    console.log(`${frt} cannot pass.`);
  }
}