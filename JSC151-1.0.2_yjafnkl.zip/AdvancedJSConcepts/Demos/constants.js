const a = ['banana', 'apple'];

console.log(a);

// OK to change object constant points to.
a.push('peach');

console.log(a);

try {
  // Not OK to assign new value to constant.
  a = ['banana', 'apple', 'peach', 'cherry'];
} catch(e) {
  console.log('Error: ' + e.message);
}