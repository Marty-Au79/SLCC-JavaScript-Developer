function greenGlassDoor(word) {
  let letter = '';
  for (let i = 0; i < word.length; i++) {
    const newLetter = word.charAt(i).toLowerCase();
    if (newLetter === letter) {
      return i;
    }
    letter = newLetter;
  }
  return 0;
}

const randomstring = require('randomstring');
const testWords = [];
for (let i=0; i<10; i++) {
  const word = randomstring.generate({
    length: 10,
    charset: 'alphabetic'
  });
  testWords.push(word);
}

for (let w of testWords) {
  const i = greenGlassDoor(w);
  if (i) {
    console.log(`${w} passes: ${w[i-1]}${w[i]} at position ${i}.`);
  } else {
    console.log(`${w} cannot pass.`);
  }
}