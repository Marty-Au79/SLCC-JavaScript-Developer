function countMarbles(personName, ...marbles) {
  console.log(personName + ' has ' + marbles.length + ' marbles.');  
}

countMarbles('Joe', 'blue', 'green', 'yellow');