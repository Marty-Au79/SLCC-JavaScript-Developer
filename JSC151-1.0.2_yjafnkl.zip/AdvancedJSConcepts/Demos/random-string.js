// First run npm install randomstring
// Documentation at https://www.npmjs.com/package/randomstring

var randomstring = require('randomstring');

const a = randomstring.generate();
console.log(a);

const b = randomstring.generate(7);
console.log(b);

const c = randomstring.generate({
  length: 12,
  charset: 'alphabetic'
});
console.log(c);
 
const d = randomstring.generate({
  charset: 'abc'
});
console.log(d);