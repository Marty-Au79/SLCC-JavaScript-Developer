// import modules
import {init, addItem, removeItem} from './modules/data.js';
import create from './modules/list.js';

// create data object
const data = init();

// add items to data object
addItem(data, 'NY', 'New York');
addItem(data, 'CA', 'California');
addItem(data, 'TX', 'Texas');
addItem(data, 'FL', 'Florida');

// remove an item from the data object
removeItem(data, 'CA');

// call create, passing the data, the id of the target, and a heading
create(data, 'my-data', 'State Abbreviations');