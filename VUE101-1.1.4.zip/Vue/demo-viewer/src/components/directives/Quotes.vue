<template>
  <div>
    <button class="btn btn-primary"
      v-for="quote in quotes" :key="quote.id"
      @click="currentQuoteId=quote.id"
      :disabled="isCurrentQuoteButton(quote)">{{quote.president}}</button>
    <article v-html="content"></article>
  </div>
</template>

<script>
export default {
  name: "Quotes",
  data: function() {
    return {
      currentQuoteId: 1,
      quotes: [
        {
          id: 1,
          president: "Washington",
          content: `It is <strong>infinitely</strong> better to have
                    a few <em>good</em> men than many
                    <em>indifferent</em> ones.`
        },
        {
          id: 2,
          president: "Adams",
          content: `<em>If conscience disapproves</em>, the
                    <strong>loudest</strong> applauses of the
                    world are of little value.`
        },
        {
          id: 3,
          president: "Jefferson",
          content: `The most valuable of all talents is that
                    of never using <em>two</em> words when
                    <em>one</em> will do.`
        }
      ]
    }
  },
  computed: {
    content: function() {
      const quote = this.quotes.find(quote => {
        return quote.id === this.currentQuoteId
      });
      return `<q>${quote.content}</q><br/> - ${quote.president}`;
    }
  },
  methods: {
    isCurrentQuoteButton(quote) {
      return (this.currentQuoteId === quote.id);
    }
  }
}
</script>
<style scoped>
  article {
    margin-left: 15em;
    text-indent: -13em;
  }

  button {
    text-decoration: none;
    margin: 1em;
    width: 200px;
  }

  button[disabled] {
    background-color: yellow;
    color: darkblue;
    cursor: not-allowed;
    font-variant: small-caps;
  }
</style>