<template>
  <div>
    <h2>Age: {{age}}</h2>
    <div v-if="age >= 18">
      <p>You can legally drive and vote.</p>
    </div>
    <div v-else-if="age >= 16">
      <p>You can legally drive, but you can't legally vote.</p>
    </div>
    <div v-else>
      <p>You cannot legally drive or vote.</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Age",
  props: {
    age: Number
  }
}
</script>
<style scoped>
  p {
    font-size: 1rem;
    font-weight: normal;
  }
</style>