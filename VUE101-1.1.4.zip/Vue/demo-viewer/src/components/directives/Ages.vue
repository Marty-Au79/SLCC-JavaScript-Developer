<template>
  <div>
    <Age :age="15"/>
    <Age :age="17"/>
    <Age :age="22"/>
  </div>
</template>

<script>
import Age from "./Age"

export default {
  name: "Ages",
  components: {
    Age
  }
}
</script>