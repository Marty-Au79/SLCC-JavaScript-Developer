<template>
  <div>
    <h3>{{list.name}}</h3>
    <ol>
      <li v-for="item in list.list" :key="item">{{item}}</li>
    </ol>
  </div>
</template>

<script>
export default {
  name: "List",
  props: {
    list: Array
  }
}
</script>