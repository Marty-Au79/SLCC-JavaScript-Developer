<template>
  <div id="ad">
    <button id="close-button" v-show="num <= start - 3"
      @click="$emit('hide-me', 'fade')">X</button>
    <div id="ad-text">
      <h1>Reasons to Buy Our Widgets</h1>
      <p>{{reasons[reasonNum]}}</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "Ad",  
  props: {
    start: Number
  },
  data: function() {
    return {
      num: this.start,
      reasons: [
        "They're the cheapest!", "They're the coolest!",
        "They're the hottest!", "They're the awesomest!",
        "They're the prettiest!", "They're the best!"
      ],
      reasonNum: 0
    }
  },
  methods: {
    countDown() {
      this.num--;
      this.reasonNum++;
      if (this.num < 0) {
        this.$emit('hide-me');
      } else {
        setTimeout(this.countDown, 1000);
      }
    }
  },
  created: function() {
    setTimeout(this.countDown, 1000);
  }
}
</script>
<style scoped>
  #ad {
    background-color:rgba(0,0,51,.6);
    border: 1px solid black;
    color: white;
    height: 100%;
    left: 50%;
    position: fixed;
    text-align: center;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 100%;
  }

  #ad-text {
    cursor: pointer;
    font-size: 2em;
    margin-top: 1em;
  }

  #ad button {
    border: 1px solid white;
    color: white;
    text-decoration: none;
  }

  #close-button {
    background-color:rgba(0,0,51,1);
    color: black;
    height: 2em;
    padding: .2em;
    position: absolute;
    right: 1em;
    top: 1em;
    width: 2em;
  }

  #num {
    font-size: 5em;
  }
</style>