<template>
  <div>
    <h2>Text Input and Textarea</h2>
    <h3>{{message}}</h3>
    <input v-model="message" class="form-control">

    <h3>{{comments}}</h3>
    <textarea v-model="comments" class="form-control"></textarea>

    <h2>Checkbox</h2>
    <h3>{{isChecked}}</h3>
    <input type="checkbox" v-model="isChecked">

    <h2>Radio Buttons</h2>
    <h3>{{fruit}}</h3>
    <input name="fruit" value="banana" type="radio" v-model="fruit"> Banana
    <input name="fruit" value="apple" type="radio" v-model="fruit"> Apple
    <input name="fruit" value="pear" type="radio" v-model="fruit"> Pear

    <h2>Select Menu</h2>
    <h3>{{veggie}}</h3>
    <select name="veggie" v-model="veggie">
      <option disabled value="">Select a veggie</option>
      <option value="eggplant">Eggplant</option>
      <option value="squash">Squash</option>
      <option value="zucchini">Zucchini</option>
    </select>
  </div>
</template>

<script>
export default {
  name: "VModel",
  data: function() {
    return {
      message: 'Change me.',
      comments: '',
      isChecked: true,
      fruit: 'pear',
      veggie: 'squash'
    }
  }
}
</script>

<style scoped>
  h2 {
    background-color: whitesmoke;
    border-bottom: 1px solid silver;
    border-top: 1px solid silver;
    margin: .4em 0;
  }

  h3 {
    background-color: aliceblue;
    margin: .4em 0;
    padding: .2em;
  }

  div {
    margin-bottom: 2em;
  }
</style>