<template>
  <div class="container">
    <Ad :start="5" @hide-me="hideMe($event)" v-show="visible"
      :class="className" />
    <p class="text-center">This is the page you were waiting for.</p>
  </div>
</template>

<script>
import Ad from './Ad.vue'
export default {
  name: "AdContainer",
  components: {
    Ad
  },
  data: function() {
    return {
      visible: true,
      className: ''
    }
  },
  methods: {
    hideMe(className) {
      if (className) {
        this.className = className;
      } else {
        this.visible = false;
      }
    }
  }
}
</script>