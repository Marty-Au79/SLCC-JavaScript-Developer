<template>
  <div id="quiz">
    <strong>Total Attempts:</strong> {{totalAttempts}} <br />
    <strong>Correct Responses:</strong> {{correctResponses}} <br />
    <strong>Grade:</strong> {{grade}}
    <h2>{{question.question}}</h2>
    <button class="btn btn-primary m-3" v-on:click="checkAnswer(answer)"
      v-for="answer in question.answers"
      v-bind:key="answer">{{answer}}</button>
    <strong class="text-danger" v-show="wrongAnswer">Wrong!</strong>
  </div>
</template>

<script>
import quiz from './presidents-quiz.js';
export default {
  name: "Quiz",
  data: function() {
    return {
      quiz: quiz,
      quizTitle: quiz.title,
      qNum: 0,
      totalAttempts: 0,
      correctResponses: 0,
      wrongAnswer: false
    }
  },
  computed: {
    question: function() {
      return this.quiz.questions[this.qNum]
    },
    grade() {
      if (this.totalAttempts === 0) {
        return 0;
      }
      const grade = (this.correctResponses / this.totalAttempts) * 100;
      return Math.round(grade);
    }
  },
  methods: {
    checkAnswer(answer) {
      this.totalAttempts++;
      if (this.question.correct === answer) {
        this.correctResponses++;
        this.nextQuestion();
      } else {
        this.wrongAnswer = true;
      }
    },
    nextQuestion() {
      this.wrongAnswer = false;
      if (this.qNum < this.quiz.questions.length-1) {
        this.qNum++;
      } else {
        this.qNum = 0;
      }
    }
  }
}
</script>

<style scoped>
  button {
    text-decoration: none;
  }
</style>