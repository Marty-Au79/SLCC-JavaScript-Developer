<template>
  <div>
    <button class="btn btn-primary"
      v-for="president in presidents" :key="president.id">
      {{president.name}}
    </button>
  </div>
</template>

<script>
export default {
  name: "PresidentButtons",
  data: function() {
    return {
      presidents: [
        {
          id: 1,
          name: "Washington"
        },
        {
          id: 2,
          name: "Adams"
        },
        {
          id: 3,
          name: "Jefferson"
        }
      ]
    }
  },
}
</script>
<style scoped>
  button {
    text-decoration: none;
    margin: 1em;
    width: 200px;
  }

  button[disabled] {
    background-color: yellow;
    color: darkblue;
    cursor: not-allowed;
    font-variant: small-caps;
  }
</style>