<template>
  <div>
    <h2>Lists</h2>
    <ol id="list-of-lists">
      <li v-for="list in lists" :key="list.name"
        @click="listToShow=list">
        <span :class="{link: isLink(list.name)}">{{list.name}}</span>
      </li>
    </ol>
    <List :list="listToShow" />
  </div>
</template>

<script>
import List from "./List"

export default {
  name: "Lists",
  components: {
    List
  },
  data: function() {
    return {
      lists: [
        {
         name: "Fruit",
         list: ['banana', 'apple', 'pear', 'lemon']
        },
        {
         name: "Veggies",
         list: ['eggplant', 'squash', 'zucchini']
        },
        {
         name: "Colors",
         list: ['red', 'green', 'blue', 'yellow', 'orange']
        }
      ],
      listToShow: ""
    }
  },
  methods: {
    isLink: function(name) {
      return name !== this.listToShow.name;
    }
  }
}
</script>

<style scoped>
  #list-of-lists {
    font-size: larger;
  }
  
  #list-of-lists li span.link {
    color: blue;
    text-decoration: underline;
    cursor: pointer;
  }
</style>