<template>
  <div>
    <h3>{{seconds}}</h3>
    <p v-show="seconds % 2 === 0">I love chocolate!</p>
    <p v-show="seconds % 2 === 1">I love vanilla!</p>
  </div>
</template>

<script>
export default {
  name: "VShow",
  data: function() {
    return {
      seconds: new Date().getSeconds()
    }
  }
}
</script>