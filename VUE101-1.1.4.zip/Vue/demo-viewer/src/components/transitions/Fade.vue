<template>
  <div class="container">
    <button class="btn btn-primary" @click="visible = !visible">
      {{toggleCommand}}
    </button>
    <transition name="fade">
      <h1 v-show="visible">Hello, world!</h1>
    </transition>
  </div>
</template>

<script>
  export default {
    name: "Fade",
    data: function() {
      return {
        visible: false,
      }
    },
    computed: {
      toggleCommand: function() {
        return (this.visible ? 'Hide' : 'Show');
      }
    }
  }
</script>

<style scoped>
  .fade-enter {
    opacity: 0;
  }

  .fade-enter-active {
    transition: opacity 5s;
  }

  .fade-enter-to {
    opacity: 1;
  }

  .fade-leave {
    opacity: 1;
  }

  .fade-leave-active {
    transition: opacity 5s;
  }

  .fade-leave-to {
    opacity: 0;
  }
</style>