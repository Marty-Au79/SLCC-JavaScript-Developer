<template>

  <main id="app" class="container">
    <nav>
      <ol>
        <li>Basic Vue Features
          <ol>
            <li><router-link to="/curly-braces">Curly Braces</router-link></li>
            <li><router-link to="/v-html">v-html Directive</router-link></li>
            <li>props
              <ol>
                <li><router-link to="/reverse-string/Chris">Reverse "Chris"</router-link></li>
                <li><router-link to="/reverse-string/Nat">Reverse "Nat"</router-link></li>
                <li><router-link to="/square/5">Square 5</router-link></li>
              </ol>
            </li>
            <li>computed
              <ol>
                <li><router-link to="/reverse-string-computed/Chris">Reverse "Chris" Computed</router-link></li>
                <li><router-link to="/reverse-string-computed/Nat">Reverse "Nat" Computed</router-link></li>
              </ol>
            </li>
            <li>data and methods
              <ol>
                <li><router-link to="/spell-words">Spell Words</router-link></li>
              </ol>
            </li>
          </ol>
        </li>
        <li>Directives
          <ol>
            <li><router-link to="/v-show">v-show</router-link></li>
            <li><router-link to="/ages">Ages</router-link></li>
            <li><router-link to="/v-model">v-model</router-link></li>
            <li><router-link to="/president-buttons">President Buttons</router-link></li>
            <li><router-link to="/counter">Counter</router-link></li>
            <li><router-link to="/quotes">Quotes</router-link></li>
            <li><router-link to="/ads">Ad Container</router-link></li>
            <li><router-link to="/lists">Lists</router-link></li>
            <li><router-link to="/quiz">Quiz</router-link></li>
          </ol>
        </li>
        <li>Transitions
          <ol>
            <li><router-link to="/fade">Fade Transition</router-link></li>
          </ol>
        </li>
      </ol>
    </nav>
  </main>
</template>

<script>
export default {
  name: 'Home',
  data: function() {
    return {
      colors: ['red', 'blue', 'green']
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  nav li {
    display: block;
    font-size: larger;
    font-weight: bold;
  }

  nav li li {
    display: list-item;
    font-size: 1rem;
    font-weight: normal;
    list-style-type: decimal;
  }

  nav li li li {
    list-style-type: lower-alpha;
  }
</style>
