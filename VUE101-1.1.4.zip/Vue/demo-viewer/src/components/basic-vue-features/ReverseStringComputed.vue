<template>
  <h2>{{reversedString}}</h2>
</template>

<script>
export default {
  name: "ReverseStringComputed",
  props: {
    stringToReverse: String
  },
  computed: {
    reversedString: function() {
      return this.stringToReverse.split('').reverse().join('');
    }
  }
}
</script>