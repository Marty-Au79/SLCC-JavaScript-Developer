<template>
  <div>
    <SpellWord word="Tomato" />
    <SpellWord word="Abandon" />
    <SpellWord word="Lollipop" />
    <SpellWord word="Fascinate" />
    <SpellWord word="Noticeable" />
    <SpellWord word="Accommodate" />
  </div>
</template>

<script>
import SpellWord from './SpellWord.vue';

export default {
  name: "SpellWords",
  components: {
    SpellWord
  }
}
</script>