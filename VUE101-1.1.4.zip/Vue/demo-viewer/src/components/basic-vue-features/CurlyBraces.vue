<template>
  <div>
    <p>Hello, {{firstName.toUpperCase()}}!</p>
  </div>
</template>

<script>
export default {
  name: "CurlyBraces",
  data: function() {
    return {
      firstName: 'Chris'
    }
  }
}
</script>