<template>
  <div>
    <p>{{title}}</p>
    <p v-html="title"></p>
  </div>
</template>

<script>
export default {
  name: "VHtml",
  data: function() {
    return {
      title: "My <em>Important</em> Post!"
    }
  }
}
</script>