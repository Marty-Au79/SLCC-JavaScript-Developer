<template>
  <div>
    <h2>Square of {{num}}</h2>
    <p>{{num}}<sup>2</sup> = {{num * num}}</p>
  </div>
</template>

<script>
export default {
  name: "Square",
  props: {
    num: Number
  }
}
</script>
<style scoped>
  p {
    font-size: 3em;
    margin-top: 0;
  }
  sup {
    font-size: .5em;
    vertical-align: .5em;
  }
</style>