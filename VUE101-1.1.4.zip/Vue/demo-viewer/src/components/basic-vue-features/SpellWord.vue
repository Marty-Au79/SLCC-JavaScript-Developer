<template>
  <div>
    <p>{{wordToSpell}}</p>
  </div>
</template>

<script>
export default {
  name: "SpellWord",
  props: {
    word: String
  },
  data: function() {
    return {
      index: 0,
      wordToSpell: ''
    }
  },
  methods: {
    spell() {
      if (this.index < this.word.length) {
        this.index++;
        this.wordToSpell = this.word.toLowerCase().substring(0, this.index);
        setTimeout(this.spell, 500);
      } else {
        this.wordToSpell = this.word.toUpperCase();
      }
    }
  },
  created: function() {
    this.spell();
  }
}
</script>