<template>
  <h2>{{stringToReverse.split('').reverse().join('')}}</h2>
</template>

<script>
export default {
  name: "ReverseString",
  props: {
    stringToReverse: String
  }
}
</script>