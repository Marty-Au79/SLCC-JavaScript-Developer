import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)
import AdContainer from './components/directives/AdContainer.vue'
import Ages from './components/directives/Ages.vue'
import Counter from './components/directives/Counter.vue'
import CurlyBraces from './components/basic-vue-features/CurlyBraces.vue'
import Fade from './components/transitions/Fade.vue'
import Home from './components/Home.vue'
import Lists from './components/directives/Lists.vue'
import ReverseString from './components/basic-vue-features/ReverseString.vue'
import ReverseStringComputed from './components/basic-vue-features/ReverseStringComputed.vue'
import PresidentButtons from './components/directives/PresidentButtons.vue'
import Quiz from './components/directives/quiz/Quiz.vue'
import SpellWords from './components/basic-vue-features/SpellWords.vue'
import Square from './components/basic-vue-features/Square.vue'
import Quotes from './components/directives/Quotes.vue'
import VHtml from './components/basic-vue-features/VHtml.vue'
import VModel from './components/directives/VModel.vue'
import VShow from './components/directives/VShow.vue'

const routes = [
  { path: '/', component: Home },
  { path: '/ads', component: AdContainer },
  { path: '/ages', component: Ages },
  { path: '/counter', component: Counter },
  { path: '/curly-braces', component: CurlyBraces },
  { path: '/fade', component: Fade },
  { path: '/lists', component: Lists },
  { path: '/reverse-string/:stringToReverse', component: ReverseString, props: true },
  { path: '/reverse-string-computed/:stringToReverse', component: ReverseStringComputed, props: true },
  { path: '/president-buttons', component: PresidentButtons },
  { path: '/quiz', component: Quiz },
  { path: '/spell-words', component: SpellWords },
  { path: '/square/:num', component: Square, props: true },
  { path: '/quotes', component: Quotes },
  { path: '/lists', component: Lists },
  { path: '/v-html', component: VHtml },
  { path: '/v-model', component: VModel },
  { path: '/v-show', component: VShow }
]

Vue.config.productionTip = false

const router = new VueRouter({
  routes // short for `routes: routes`
})

// new Vue({
//   render: h => h(App),
// }).$mount('#app')

new Vue({
  router,
}).$mount('#app')
