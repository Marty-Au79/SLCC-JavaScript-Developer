<template>
  <main id="main-container">
    <div v-if="screen === 'config'" id="config-container">
      <h1>Mathificent</h1>
      <SelectInput :currentValue="operation" label="Operation"
        id="operation" v-model="operation" :options="operations" />
      <SelectInput :currentValue="maxNumber" label="Maximum Number"
        id="max-number" v-model="maxNumber" :options="numbers" />
      <PlayButton @play-button-click="play" />
    </div>
    <div v-else-if="screen === 'play'" id="game-container" class="text-center">
      <button class="btn btn-success" @click="config">Change Game</button>
    </div>
  </main>
</template>

<script>
  import SelectInput from './SelectInput';
  import PlayButton from './PlayButton';

  export default {
    name: 'Main',
    components: {
      SelectInput,
      PlayButton
    },
    data: function() {
      return {
        operations: [
          ['Addition', '+'],
          ['Subtraction', '-'],
          ['Multiplication', 'x'],
          ['Division', '/']
        ],
        operation: 'x',
        maxNumber: '10',
        screen: 'config'
      }
    },
    methods: {
      config() {
        this.screen = "config";
      },
      play() {
        this.screen = "play";
      }
    },
    computed: {
      numbers: function() {
        const numbers = [];
        for (let number = 2; number <= 100; number++) {
            numbers.push([number, number]);
        }
        return numbers;
      }
    }
  }
</script>

<style scoped>
  #main-container {
    margin: auto;
    width: 380px;
  }
</style>