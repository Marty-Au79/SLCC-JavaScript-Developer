<template>
  <main id="main-container">
    <h1>Mathificent</h1>
    <SelectInput label="Operation" id="operation" :options="operations" />
    <SelectInput label="Maximum Number" id="max-number" :options="numbers" />
    <PlayButton />
  </main>
</template>

<script>
  import SelectInput from './SelectInput';
  import PlayButton from './PlayButton';

  export default {
    name: 'Main',
    components: {
      SelectInput,
      PlayButton
    },
    data: function() {
      return {
        operations: [
          ['Addition', '+'],
          ['Subtraction', '-'],
          ['Multiplication', 'x'],
          ['Division', '/']
        ],
      }
    },
    computed: {
      numbers: function() {
        const numbers = [];
        for (let number = 2; number <= 100; number++) {
            numbers.push([number, number]);
        }
        return numbers;
      }
    }
  }
</script>

<style scoped>
  #main-container {
    margin: auto;
    width: 380px;
  }
</style>