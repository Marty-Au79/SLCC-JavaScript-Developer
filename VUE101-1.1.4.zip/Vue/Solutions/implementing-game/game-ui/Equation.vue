<template>
  <div id="equation" class="row">
    <div class="col-5">1+1</div>
    <div class="col-2">=</div>
    <div class="col-5">2</div>
  </div>
</template>

<script>
  export default {
    name: 'Equation'
  }
</script>

<style scoped>
  #equation {
    font-size: 1.6em;
    margin: auto;
    width: 90%;
  }
</style>