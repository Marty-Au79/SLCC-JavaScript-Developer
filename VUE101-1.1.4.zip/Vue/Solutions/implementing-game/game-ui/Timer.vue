<template>
  <strong>Time Left: 60</strong>
</template>

<script>
  export default {
    name: 'Timer'
  }
</script>