<template>
  <strong>Score: 0</strong>
</template>

<script>
  export default {
    name: 'Score'
  }
</script>