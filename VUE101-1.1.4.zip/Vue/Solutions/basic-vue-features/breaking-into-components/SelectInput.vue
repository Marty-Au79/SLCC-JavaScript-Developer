<template>
  <div>
    <label for="select">Select Label</label>
    <select id="select">
      <option value="sample value">Sample Value</option>
    </select>
  </div>
</template>

<script>
  export default {
    name: 'SelectInput'
  }
</script>