<template>
  <button class="btn btn-primary">Play!</button>
</template>

<script>
  export default {
    name: 'PlayButton'
  }
</script>