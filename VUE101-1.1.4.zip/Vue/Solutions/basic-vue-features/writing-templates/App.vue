<template>
  <div id="app">
    <header>
      <nav class="navbar navbar-expand-lg navbar-dark">
        <button class="navbar-toggler" type="button" 
          data-toggle="collapse" data-target="#navbarText">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav mr-auto text-left">
            <li class="nav-item active">
              <a class="nav-link" href="/">Home</a>
            </li>
          </ul>
        </div>
        <a class="navbar-brand" href="/">Mathificent</a>
      </nav>
    </header>
    <h1>Mathificent</h1>
    <footer class="navbar fixed-bottom">
      <a href="https://www.webucator.com" class="text-light">
        Copyright &copy; {{new Date().getFullYear()}} Webucator
      </a>
    </footer>
  </div>
</template>

<script>
export default {
  name: 'app',
  components: {
  }
}
</script>

<style>
header, footer {
  background-color: #3f7cad;
}
</style>