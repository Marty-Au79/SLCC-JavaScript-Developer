<template>
  
    <footer class="navbar fixed-bottom">
      <a href="https://www.webucator.com" class="text-light">
        Copyright &copy; {{new Date().getFullYear()}} Webucator
      </a>
    </footer>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style>

</style>