async function postData(data) {
  const response = $.ajax('/coupon-check', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(data)
    })
    .done(function(response) {
      return response;
    });
  return response;
}

function checkCouponCode() {
  const coupon = document.getElementById('coupon').value;
  const data = {
    coupon: coupon
  };
  const output = document.getElementById("coupon-message");
  output.innerHTML = "validating...";
  postData(data)
    .then(response => {
      output.innerHTML = response
    });

}
window.addEventListener('load', function(e) {
  const btnCoupon = document.getElementById('btn-coupon');
  btnCoupon.addEventListener('click', checkCouponCode);
});