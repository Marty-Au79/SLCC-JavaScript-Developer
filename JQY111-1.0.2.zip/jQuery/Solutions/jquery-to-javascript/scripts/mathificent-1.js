/******************************************************************************
  Global variables
******************************************************************************/
let high; // The highest number used in equations.
let low = 0; // The lowest number used in equations.
let operator; // The operator currently being used.


/******************************************************************************
  Utility Functions
******************************************************************************/
function randInt(low, high) {
  /* Utility function for getting random integer. */
  return Math.floor(Math.random() * (high - low + 1) + low);
}


/******************************************************************************
  Common Functions
******************************************************************************/
function captureChangeViewEvents() {
  // Cache reused elements
  const configContainer = $('#config-container');
  const gameContainer = $('#game-container');
  const timesUpContainer = $('#times-up-container');

  // Capture play button clicks
  $('#btn-play-button').click(function() {
    // Set global variable: high
    high = Number($('#max-number').val());

    // Set global variable: operator
    switch ($('#operation').val()) {
      case 'addition':
        operator = '+';
        break;
      case 'subtraction':
        operator = '-';
        break;
      case 'multiplication':
        operator = 'x';
        break;
      case 'division':
        operator = '/';
    }
    switchSection(configContainer, gameContainer);
    play();
  });

  // Capture play-again button clicks
  $('#btn-play-again').click(function() {
    switchSection(timesUpContainer, gameContainer);
    play();
  });

  // Capture change-settings button clicks
  $('#btn-change-settings').click(function() {
    switchSection(timesUpContainer, configContainer);
  });
}

function switchSection(hideSection, showSection) {
  // Hide one section and display another
  hideSection.toggle('display');
  showSection.toggle('display');

  // If leaving game, turn off game event capturing
  if (hideSection.attr('id') === 'game-container') {
    captureGameEvents('off');
  }

  // If starting game, turn on game event capturing
  if (showSection.attr('id') === 'game-container') {
    captureGameEvents('on');
  }
}

/******************************************************************************
  Config View Functions
******************************************************************************/
function populateSelects() {
  // Cache reused elements
  const operationSelect = $('#operation');
  const maxNumberSelect = $('#max-number');

  // Populate operator options
  const operations = ['Addition', 'Subtraction', 'Multiplication', 'Division'];
  
  $.each(operations, function(i, val) {
    $(`<option value="${val.toLowerCase()}">${val}</option>`)
      .appendTo(operationSelect);
  });

  operationSelect.val('multiplication'); // Initial operator
  operationSelect.focus();

  // Populate max number options
  for (let i=2; i <= 100; i++) {
    $(`<option value="${i}">${i}</option>`).appendTo(maxNumberSelect);
  }
  maxNumberSelect.val(10); // Initial max number
}

/******************************************************************************
  Game View Functions
******************************************************************************/
function answerChanged(value) {
  /* 
    This is the callback function that gets called each time the user adds
    their answer. It gets the user's current answer, appends the new change,
    checks the result against the correct answer. If correct, it calls
    setEquation() to get a new equation.
  */
  // Cache reused elements
  const userSolutionElem = $('#user-solution');
  const scoreElem = $('#score');

  const correctAnswer = getCorrectAnswer(operator);
  let score = Number(scoreElem.text());
  let userAnswer = Number(userSolutionElem.text());

  if (userAnswer === 0) {
    // If userAnswer is 0, don't append, just change the value.
    // This prevents answers like "05"
    userSolutionElem.text(value);
  } else {
    // Append the new value to the user's previous answer.
    userSolutionElem.append(value);
  }

  // Retrieve and convert the new answer to an integer.
  userAnswer = Number(userSolutionElem.text());

  // Check if the answer is correct
  if (correctAnswer === userAnswer) {
    score++;
    scoreElem.text(score.toString()); // Update scoreboard.
    userSolutionElem.text(''); // Clear user answer.
    setEquation(operator, low, high); // Get new equation.
  };
}

function captureGameEvents(onoff = 'on') {
  /*
    This is used to turn event capturing for game-play events on and off. Its
    primary purpose is for keyboard events, as the use can continue to press
    keys after the game view has disappeared.
  */

  // Decide whether we are adding or removing events.
  // We no longer need this as we can pass onoff to the jQuery object
  // const eventAction = (onoff === 'on') ?
  //   'addEventListener' : 'removeEventListener';

  // Add/Remove click event to all number buttons.
  $('section#game-container .number-button')[onoff]('click', numButtonClicked);

  // Add/Remove click event to clear button.
  $('#btn-clear-button')[onoff]('click', clearButtonClicked);

  // Add/Remove keyup events to enable keyboard play.
  $(document)[onoff]('keyup', keyPressed);
}

function clearButtonClicked() {
  $('#user-solution').text('');
}

function getCorrectAnswer(oper) {
  /* Calculate and return correct answer. */
  const num1 = Number($('#num1').text());
  const num2 = Number($('#num2').text());
  switch (oper) {
    case '+':
      return num1 + num2;
    case '-':
      return num1 - num2;
    case 'x':
      return num1 * num2;
    case '/':
      return num1 / num2;
  }
}

function keyPressed(e) {
  /* Callback function to keyboard clicks. */
  // Cache reused elements
  const userSolutionElem = $('#user-solution');

  const value = e.key;
  if (e.keyCode === 8 || e.keyCode == 46) { // backspace
    const currentAnswer = userSolutionElem.text();
    if (currentAnswer.length) {
      const newAnswer = currentAnswer.substring(0, currentAnswer.length - 1);
      userSolutionElem.text(newAnswer);
    }
  } else if (e.keyCode === 32) { // spacebar
    userSolutionElem.text('');
  } else if (e.keyCode >= 48 && e.keyCode <= 57) { // Number keys
    answerChanged(value);
  }
}

function numButtonClicked(e) {
  /* Callback function to number button clicks. */
  const btn = $(e.target); // Which button?
  const value = btn.attr('data-value'); // Get the value of the clicked button.
  answerChanged(value); // Change the answer.
}

function play() {
  /* Start playing. */
  $('#time-left').text(60); // seconds left
  $('#score').text(0);
  setEquation();
  startTimer();
}

function setEquation() {
  /* Sets the equation. */
  // Cache reused elements
  const userSolutionElem = $('#user-solution');
  const equationElem = $('#equation');

  let num1 = randInt(low, high);
  let num2 = randInt(low, high, true);
  if (operator === '-') { // Subtract smaller number from bigger number.
    num1 = Math.max(num1, num2);
    num2 = Math.min(num1, num2);
  } else if (operator === '/') {
    while (num2 === 0) { // No division by zero
      num2 = randInt(low, high);
    }
    // Make num1 the product of num1 x num2, so that the equation is num1/num2.
    // e.g., if the random numbers are 5 and 7, the equation will be 35 / 7.
    num1 = num1 * num2;
  }

  // Create the spans to hold the operands
  const spanNum1 = '<span id="num1">' + num1.toString() + '</span>';
  const spanNum2 = '<span id="num2">' + num2.toString() + '</span>';

  // Clear the user answer.
  userSolutionElem.text('');

  equationElem.html(spanNum1 + ' ' + operator + ' ' + spanNum2);
}

function startTimer() {
  // Start the Timer Countdown.
  const timer = setInterval(function() {
    const timeLeft = $('#time-left');

    let secondsLeft = Number(timeLeft.text());
    secondsLeft--;
    timeLeft.text(secondsLeft.toString());

    if (secondsLeft < 10) { // Start changing background color.
      const a = (10 - secondsLeft) * .1;
      const bgColor = 'rgb(255,204,102,' + a + ')';
      $('body').css({
        backgroundColor: bgColor
      });
    }

    if (secondsLeft === 0) { // Times up.
      const score = Number($('#score').text());
      clearInterval(timer);
      timesUp(score);
    }
  }, 1000);
}

function timesUp(score) {
  $('body').css({
    backgroundColor: '#fff'  // Reset background to white.
  });

  // Show the times-up view.
  switchSection(
    $('#game-container'),
    $('#times-up-container')
  );

  // Show the score.
  $('#final-score').text(score);
}

/******************************************************************************
  Initial Load
******************************************************************************/
window.addEventListener('load', (e) => {
  populateSelects();
  captureChangeViewEvents();
});