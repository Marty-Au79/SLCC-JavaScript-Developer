async function postData(data) {
  const response = await fetch('/coupon-check', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  });
  return response.text();
}

function checkCouponCode() {
  const coupon = document.getElementById('coupon').value;
  const data = {
    coupon: coupon
  };
  const output = document.getElementById("coupon-message");
  output.innerHTML = "validating...";
  postData(data)
    .then(response => {
      output.innerHTML = response
    });

}
window.addEventListener('load', function(e) {
  const btnCoupon = document.getElementById('btn-coupon');
  btnCoupon.addEventListener('click', checkCouponCode);
});