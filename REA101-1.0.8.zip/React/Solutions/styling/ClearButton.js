import React from 'react';

function ClearButton(props) {
  return (
    <button className="btn btn-primary"
      style={{width: "4.2em"}}>Clear</button>
  )
}

export default ClearButton;