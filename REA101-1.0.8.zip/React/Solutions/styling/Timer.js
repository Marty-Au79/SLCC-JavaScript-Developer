import React from 'react';

function Timer(props) {
  return (
    <strong>Time: {props.timeLeft}</strong>
  )
}

export default Timer;