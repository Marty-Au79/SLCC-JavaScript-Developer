import React from 'react';

function Score(props) {
  return (
    <strong>Score: {props.score}</strong>
  )
}

export default Score;