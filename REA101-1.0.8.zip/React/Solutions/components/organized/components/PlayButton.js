import React from 'react';

function PlayButton() {
  return(
    <button>Play!</button>
  )
}

export default PlayButton;