import React from 'react';

function SayHello() {
    return (
      <h1>Hello, world!</h1>
    );
}

export default SayHello;