import React from 'react';
import './Apple.css';

function Apple() {
    return (
      <div className="fruit">
        Apple
      </div>
    );
}

export default Apple;