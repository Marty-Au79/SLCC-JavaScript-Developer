import React from 'react';
import './Banana.css';

function Banana() {
    return (
      <div className="fruit">
        Banana
      </div>
    );
}

export default Banana;