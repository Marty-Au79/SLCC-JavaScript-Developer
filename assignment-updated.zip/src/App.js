import { Routes, Route, BrowserRouter } from "react-router-dom";
import AnagramHunt from "./pages/AnagramHunt";
import Home from "./pages/Home";
import MathFacts from "./pages/MathFacts";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/anagram-hunt" element={<AnagramHunt />} />
          <Route path="/math-facts" element={<MathFacts />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
