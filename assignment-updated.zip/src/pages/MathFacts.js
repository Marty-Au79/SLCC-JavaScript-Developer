/* eslint-disable eqeqeq */
/* eslint-disable no-fallthrough */
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useTimer } from "use-timer";

const MathFacts = () => {
  const [gameStart, setGameStart] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [answer, setAnswer] = useState(0);
  const [numbers, setNumbers] = useState({ first: 0, second: 0 });
  const [data, setData] = useState({ operator: "+", maxNumber: 9 });
  const [score, setScore] = useState(0);
  const { maxNumber, operator } = data;
  const { first, second } = numbers;
  const navigate = useNavigate();

  const { time, start, reset } = useTimer({
    initialTime: 60,
    timerType: "DECREMENTAL",
    endTime: 0,
    onTimeOver: () => setGameOver(true),
  });

  function getRandomInt(max) {
    return Math.floor(Math.random() * max);
  }
  const handleGenerate = () => {
    if (!gameOver) {
      setNumbers({
        first: getRandomInt(maxNumber),
        second: getRandomInt(maxNumber),
      });
    }
  };
  const handlePlay = () => {
    start();
    setGameOver(false);
    setGameStart(true);
    handleGenerate();
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    switch (operator) {
      case "+":
        if (first + second == answer) {
          setScore(score + 1);
          handleGenerate();
          break;
        }
      case "-":
        if (first - second == answer) {
          setScore(score + 1);
          handleGenerate();
          break;
        }
      case "/":
        if (first / second == answer) {
          setScore(score + 1);
          handleGenerate();
          break;
        }
      case "*":
        if (first * second == answer) {
          setScore(score + 1);
          handleGenerate();
          break;
        }
      default:
        break;
    }

    setAnswer(0);
  };
  const handleReset = () => {
    setGameStart(false);
    setGameOver(false);
    setAnswer(0);
    setScore(0);
    reset();
  };
  return (
    <div className="container">
      <h1 style={{ color: "#031b5b" }}>Math Facts Practice</h1>
      {!gameOver && !gameStart && (
        <div className="anagram_body">
          <div className="form_conatiner">
            <p style={{ width: "100%", fontWeight: 500 }}>Operation</p>
            <select
              value={operator}
              style={{ width: "100%", margin: "0.5rem 0", borderRadius: "4px" }}
              onChange={(e) =>
                setData((f) => ({ ...f, operator: e.target.value }))
              }
            >
              <option value="+">Addition</option>
              <option value="-">Subtraction</option>
              <option value="/">Division</option>
              <option value="*">Multiplication</option>
            </select>
          </div>
          <div className="form_conatiner">
            <p style={{ width: "100%", fontWeight: 500 }}>Max number</p>
            <input
              type="number"
              value={maxNumber}
              onChange={(e) =>
                setData((f) => ({ ...f, maxNumber: e.target.value }))
              }
              className="input"
            />
          </div>
          <h5>How to Play</h5>
          <ul>
            <li>Choose operation</li>
            <li>Choose Max number</li>
            <li>Press play</li>
            <li>How many problems can you slove in 60 seconds ?</li>
          </ul>
          <button className="play_btn" onClick={handlePlay}>
            Play
          </button>
        </div>
      )}
      {!gameOver && gameStart && (
        <div className="math_container">
          {operator === "+" && <h1>ADDITION</h1>}
          {operator === "-" && <h1>SUBTRACTION</h1>}
          {operator === "/" && <h1>DIVISION</h1>}
          {operator === "*" && <h1>MULTIPLICATION</h1>}
          <h2>
            {first} {operator} {second}
          </h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              value={answer}
              disabled={gameOver}
              onChange={(e) => setAnswer(e.target.value)}
              className="input anagram_input"
              placeholder="Type in anagrams"
            />
          </form>
          <h5>Score {score}</h5>
          <h4>TimeLeft {time}</h4>
        </div>
      )}
      {gameOver && (
        <div className="anagram_game_container">
          {operator === "+" && <h1>ADDITION</h1>}
          {operator === "-" && <h1>SUBTRACTION</h1>}
          {operator === "/" && <h1>DIVISION</h1>}
          {operator === "*" && <h1>MULTIPLICATION</h1>}
          <h4 style={{ fontSize: "1.2rem", margin: "0.3rem" }}>Time's Up</h4>
          <h6 style={{ fontSize: "1.2rem", margin: "0.3rem" }}>
            Your final score is
          </h6>
          <h1 style={{ fontSize: "3rem", margin: "0.5rem", fontWeight: 500 }}>
            {score}
          </h1>
          <button type="button" className="play_again" onClick={handleReset}>
            Play Again
          </button>
          <button type="button" className="play" onClick={() => navigate("/")}>
            Back to start screen
          </button>
        </div>
      )}
    </div>
  );
};
export default MathFacts;
