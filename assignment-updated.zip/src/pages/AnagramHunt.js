import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useTimer } from "use-timer";
import anagramJson from "../utils/anagramJson";

const AnagramHunt = () => {
  const navigate = useNavigate();
  const [length, setLength] = useState(5);
  const [wordsArray, setWordsArray] = useState([]);
  const [currentDone, setCurrentDone] = useState(1);
  const [wordLengthArray, setWordLengthArray] = useState([]);
  const [selectedWord, setSelectedWord] = useState("");
  const [doneArrayIndexs, setDoneArrayIndexs] = useState([]);
  const [doneWords, setDoneWords] = useState([]);
  const [iteration, setIteration] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [input, setInput] = useState("");

  function getRandomInt(max) {
    return Math.floor(Math.random() * max);
  }
  const { time, start, reset } = useTimer({
    initialTime: 60,
    timerType: "DECREMENTAL",
    endTime: 0,
    onTimeOver: () => setGameOver(true),
  });
  const handleGenerate = () => {
    if (!gameOver) {
      while (true) {
        const arr = anagramJson[length];
        setWordLengthArray(arr);
        const ran = getRandomInt(arr.length);
        const i = doneArrayIndexs.findIndex((x) => x === ran);
        if (i >= 0) {
          continue;
        }
        setDoneArrayIndexs([...doneArrayIndexs, ran]);
        setWordsArray(arr[ran]);
        const ran1 = getRandomInt(arr[ran].length);
        setSelectedWord(arr[ran][ran1]);
        setDoneWords([...doneWords, arr[ran][ran1]]);
        setIteration(iteration + 1);
        setCurrentDone(1);
        break;
      }
    }
  };

  const handlePlay = () => {
    handleGenerate();
    start();
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    const i = wordsArray.findIndex((x) => x === input);
    if (i < 0) return;
    const i1 = doneWords.findIndex((x) => x === input);
    if (i1 >= 0) return;
    setDoneWords([...doneWords, input]);
    setCurrentDone(currentDone + 1);
    setInput("");
    setScore(score + 1);
    if (wordLengthArray.length === iteration) {
      return setGameOver(true);
    }

    if (currentDone + 1 === wordsArray.length) {
      handleGenerate();
    }
  };
  const handleReset = () => {
    setGameOver(false);
    reset();
    setWordLengthArray([]);
    setWordsArray([]);
    setCurrentDone(1);
    setSelectedWord("");
    setDoneArrayIndexs([]);
    setDoneWords([]);
    setIteration(0);
    setInput("");
    setScore(0);
  };

  return (
    <div className="container">
      <h1 style={{ color: "#031b5b" }}>Anagram Hunt</h1>
      {!gameOver && wordsArray.length === 0 ? (
        <div className="anagram_body">
          <div className="form_conatiner">
            <p style={{ width: "100%", fontWeight: 500 }}>Word Length</p>
            <input
              type="number"
              value={length}
              onChange={(e) => setLength(e.target.value)}
              className="input"
            />
          </div>
          <h5>How to Play</h5>
          <ul>
            <li>Choose a word length</li>
            <li>Press play</li>
            <li>How many anagrams can you find in a minute?</li>
          </ul>
          <button className="play_btn" onClick={handlePlay}>
            Play
          </button>
        </div>
      ) : (
        <div className="anagram_game_container">
          <div className="anagram_game_inner">
            <h5>Score: {score}</h5>
            <h5>TimeLeft: {time}</h5>
          </div>
          <hr />
          {!gameOver && (
            <h6 className="selected_word">
              {selectedWord} ({wordsArray.length - currentDone} Left)
            </h6>
          )}
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              value={input}
              disabled={gameOver}
              onChange={(e) => setInput(e.target.value)}
              className="input anagram_input"
              placeholder="Type in anagrams"
            />
          </form>
          <div>
            <ol>
              {doneWords.map((item) => (
                <li>{item}</li>
              ))}
            </ol>
          </div>
        </div>
      )}
      {gameOver && (
        <div className="anagram_game_container">
          <h4 style={{ fontSize: "1.2rem", margin: "0.3rem" }}>Time's Up</h4>
          <h6 style={{ fontSize: "1.2rem", margin: "0.3rem" }}>You got</h6>
          <h1 style={{ fontSize: "3rem", margin: "0.5rem", fontWeight: 500 }}>
            {score}
            <br />
            Anagrams
          </h1>
          <button type="button" className="play_again" onClick={handleReset}>
            Play Again
          </button>
          <button type="button" className="play" onClick={() => navigate("/")}>
            Back to start screen
          </button>
        </div>
      )}
    </div>
  );
};
export default AnagramHunt;
