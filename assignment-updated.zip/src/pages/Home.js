import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();
  return (
    <div className="container">
      <h1>Play2Learn</h1>

      <div className="home_container">
        <div className="card">
          <div className="inner_card">
            <h3>Anagram Hunt</h3>
            <p>
              Do you like Scrabble? Words with Friends? Improve how fast you can
              recognize anagrams in a word with this neat little game!
            </p>
          </div>
          <hr className="card_hr" />
          <div className="card_action">
            <button className="play" onClick={() => navigate("/anagram-hunt")}>
              Play Now!
            </button>
          </div>
        </div>

        <div className="card">
          <div className="inner_card">
            <h3>Math Facts Practice</h3>
            <p>Improve your mental math skills with this exciting game!</p>
          </div>
          <hr className="card_hr" />
          <div className="card_action">
            <button className="play" onClick={() => navigate("/math-facts")}>
              Play Now!
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Home;
